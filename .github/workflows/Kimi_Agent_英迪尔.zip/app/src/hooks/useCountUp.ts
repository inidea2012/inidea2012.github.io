import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function useCountUp(
  target: number,
  duration: number = 1.5,
  suffix: string = ""
) {
  const ref = useRef<HTMLDivElement>(null);
  const [value, setValue] = useState(0);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const proxy = { val: 0 };

    const tween = gsap.to(proxy, {
      val: target,
      duration,
      ease: "power2.out",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        toggleActions: "play none none none",
        onEnter: () => {
          if (!hasAnimated.current) {
            hasAnimated.current = true;
          }
        },
      },
      onUpdate: () => {
        setValue(Math.round(proxy.val));
      },
    });

    return () => {
      tween.kill();
    };
  }, [target, duration]);

  return { ref, displayValue: `${value}${suffix}` };
}
