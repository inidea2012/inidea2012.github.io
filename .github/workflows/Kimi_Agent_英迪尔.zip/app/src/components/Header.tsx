import { useState, useEffect, useCallback } from "react";
import { Link, useLocation } from "react-router";
import { Search, Menu, X } from "lucide-react";
import { navLinks } from "../data/siteData";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  const isHome = location.pathname === "/";
  const isHeroVisible = isHome && !scrolled;

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  const scrollToTop = useCallback(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${
          isHeroVisible
            ? "bg-transparent text-white"
            : "bg-white/96 backdrop-blur-xl text-charcoal shadow-sm"
        }`}
        style={{ height: 72 }}
      >
        <div className="content-container h-full flex items-center justify-between">
          {/* Logo */}
          <Link
            to="/"
            onClick={scrollToTop}
            className="flex items-center gap-1 shrink-0"
          >
            <span
              className={`text-lg font-bold tracking-wide transition-colors duration-300 ${
                isHeroVisible ? "text-white" : "text-crimson"
              }`}
            >
              INIDEA
            </span>
            <span
              className={`text-lg font-normal transition-colors duration-300 ${
                isHeroVisible ? "text-white/90" : "text-charcoal"
              }`}
            >
              英迪尔
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-10">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                onClick={scrollToTop}
                className={`text-[15px] tracking-wider relative group transition-colors duration-300 ${
                  location.pathname === link.href
                    ? "text-crimson"
                    : isHeroVisible
                    ? "text-white/90 hover:text-white"
                    : "text-charcoal/80 hover:text-charcoal"
                }`}
              >
                {link.label}
                <span
                  className={`absolute -bottom-1 left-0 h-[2px] bg-crimson transition-all duration-300 ${
                    location.pathname === link.href
                      ? "w-full"
                      : "w-0 group-hover:w-full"
                  }`}
                />
              </Link>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-4">
            <button
              className={`hidden lg:flex items-center justify-center w-10 h-10 transition-colors duration-300 ${
                isHeroVisible
                  ? "text-white/80 hover:text-white"
                  : "text-charcoal/60 hover:text-charcoal"
              }`}
              aria-label="搜索"
            >
              <Search size={20} />
            </button>

            <Link
              to="/contact"
              onClick={scrollToTop}
              className={`hidden lg:inline-flex items-center px-5 py-2 text-sm tracking-wider border transition-all duration-300 ${
                isHeroVisible
                  ? "border-white/60 text-white hover:bg-white hover:text-charcoal"
                  : "border-charcoal/30 text-charcoal hover:bg-charcoal hover:text-white"
              }`}
            >
              咨询服务
            </Link>

            {/* Mobile hamburger */}
            <button
              className={`lg:hidden w-10 h-10 flex items-center justify-center transition-colors ${
                isHeroVisible ? "text-white" : "text-charcoal"
              }`}
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="菜单"
            >
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-white flex flex-col items-center justify-center gap-8 animate-in fade-in duration-300">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              onClick={scrollToTop}
              className={`text-2xl font-light tracking-wider transition-colors ${
                location.pathname === link.href
                  ? "text-crimson"
                  : "text-charcoal hover:text-crimson"
              }`}
            >
              {link.label}
            </Link>
          ))}
          <Link
            to="/contact"
            onClick={scrollToTop}
            className="mt-4 px-8 py-3 bg-crimson text-white text-lg tracking-wider"
          >
            咨询服务
          </Link>
        </div>
      )}
    </>
  );
}
