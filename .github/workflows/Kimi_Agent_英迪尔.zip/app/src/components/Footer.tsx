import { Link } from "react-router";
import { Phone } from "lucide-react";
import { contactInfo } from "../data/siteData";

export default function Footer() {
  return (
    <footer className="bg-charcoal text-white">
      <div className="content-container pt-16 md:pt-20 pb-10">
        {/* Main grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-1 mb-4">
              <span className="text-lg font-bold text-crimson tracking-wide">
                INIDEA
              </span>
              <span className="text-lg font-normal text-white/90">英迪尔</span>
            </div>
            <p className="text-sm text-white/40 font-light mb-6">
              万店级商厨设备智造商
            </p>
            <a
              href={`tel:${contactInfo.hotline}`}
              className="inline-flex items-center gap-2 text-sm text-white/80 hover:text-crimson transition-colors"
            >
              <Phone size={16} />
              全国免费热线：{contactInfo.hotline}
            </a>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-base font-medium mb-5">产品中心</h4>
            <ul className="space-y-3">
              {[
                "炸炉系列",
                "煮面炉系列",
                "冰淇淋机系列",
                "裹粉台系列",
                "汉堡机系列",
                "腌制机系列",
              ].map((item) => (
                <li key={item}>
                  <Link
                    to="/products"
                    className="text-sm text-white/40 hover:text-white transition-colors duration-250"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-base font-medium mb-5">关于英迪尔</h4>
            <ul className="space-y-3">
              {[
                { label: "了解英迪尔", href: "/about" },
                { label: "荣誉证书", href: "/about" },
                { label: "联系我们", href: "/contact" },
                { label: "新闻资讯", href: "/news" },
              ].map((item) => (
                <li key={item.label}>
                  <Link
                    to={item.href}
                    className="text-sm text-white/40 hover:text-white transition-colors duration-250"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-base font-medium mb-5">服务支持</h4>
            <ul className="space-y-3">
              {[
                { label: "服务咨询", href: "/contact" },
                { label: "售后热线", href: "/contact" },
                { label: "常见问题", href: "/news" },
              ].map((item) => (
                <li key={item.label}>
                  <Link
                    to={item.href}
                    className="text-sm text-white/40 hover:text-white transition-colors duration-250"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/30 font-light">
            © 2025 广州英迪尔电器有限公司 版权所有
          </p>
          <div className="flex items-center gap-4 text-xs text-white/30">
            <span className="hover:text-white/60 cursor-pointer transition-colors">
              隐私政策
            </span>
            <span>|</span>
            <span className="hover:text-white/60 cursor-pointer transition-colors">
              法律声明
            </span>
            <span>|</span>
            <span>粤ICP备13007540号</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
