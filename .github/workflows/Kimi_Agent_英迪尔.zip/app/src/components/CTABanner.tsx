import { useEffect, useRef } from "react";
import { Link } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Phone } from "lucide-react";
import { contactInfo } from "../data/siteData";

gsap.registerPlugin(ScrollTrigger);

interface CTABannerProps {
  mini?: boolean;
}

export default function CTABanner({ mini = false }: CTABannerProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const items = el.querySelectorAll("[data-cta-animate]");
    gsap.from(items, {
      opacity: 0,
      y: 25,
      duration: 0.7,
      stagger: 0.1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: el,
        start: "top 75%",
        toggleActions: "play none none none",
      },
    });
  }, []);

  if (mini) {
    return (
      <section className="bg-charcoal" ref={ref}>
        <div className="content-container py-14 md:py-16 text-center">
          <h3
            data-cta-animate
            className="text-xl md:text-2xl font-medium text-white"
          >
            需要了解更多设备信息？
          </h3>
          <p
            data-cta-animate
            className="text-white/50 font-light mt-3 text-sm md:text-base"
          >
            英迪尔专业团队随时为您提供产品咨询与厨房规划服务
          </p>
          <Link
            data-cta-animate
            to="/contact"
            className="inline-block mt-6 px-9 py-3.5 bg-crimson text-white text-base font-medium hover:brightness-110 hover:-translate-y-0.5 transition-all duration-300"
          >
            立即咨询
          </Link>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-charcoal" ref={ref}>
      <div className="content-container py-20 md:py-28 lg:py-32 text-center max-w-[800px] flex flex-col items-center">
        <span
          data-cta-animate
          className="text-[13px] text-white/40 tracking-[0.15em] font-light uppercase"
        >
          CONTACT US
        </span>
        <h2
          data-cta-animate
          className="font-serif text-4xl md:text-[56px] font-bold text-white tracking-wide mt-4 leading-tight"
        >
          服务全球
        </h2>
        <h3
          data-cta-animate
          className="font-serif text-2xl md:text-4xl font-medium text-white tracking-wide mt-2"
        >
          <span className="text-crimson">1000+</span> 连锁餐饮品牌
        </h3>
        <p
          data-cta-animate
          className="text-white/60 font-light text-base md:text-lg leading-relaxed mt-6 max-w-[600px]"
        >
          无论您是开设新门店还是升级现有厨房，英迪尔都能为您提供专业的设备解决方案。立即联系我们，获取专属厨房设备配置方案。
        </p>
        <div
          data-cta-animate
          className="flex flex-col sm:flex-row gap-4 mt-10"
        >
          <Link
            to="/contact"
            className="px-10 py-4 bg-crimson text-white font-medium hover:brightness-110 hover:-translate-y-0.5 transition-all duration-300"
          >
            立即咨询
          </Link>
          <Link
            to="/products"
            className="px-10 py-4 border border-white text-white font-medium hover:bg-white hover:text-charcoal transition-all duration-300"
          >
            查看产品
          </Link>
        </div>
        <p
          data-cta-animate
          className="flex items-center gap-2 text-white/50 text-base mt-8"
        >
          <Phone size={16} />
          {contactInfo.hotline}
        </p>
        <p data-cta-animate className="text-white/30 text-sm mt-2">
          广州市番禺区大龙街开发路3号之三十八
        </p>
      </div>
    </section>
  );
}
