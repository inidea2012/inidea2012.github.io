import { useState } from "react";
import { MessageSquare, Phone, MessageCircle, X, Plus } from "lucide-react";
import { contactInfo } from "../data/siteData";

export default function StickyServiceSidebar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const items = [
    {
      icon: MessageSquare,
      label: "在线咨询",
      bg: "bg-crimson",
      text: "text-white",
      border: "border-crimson",
    },
    {
      icon: Phone,
      label: contactInfo.afterSales,
      bg: "bg-white",
      text: "text-charcoal",
      border: "border-warm-stone",
      href: `tel:${contactInfo.afterSales}`,
    },
    {
      icon: MessageCircle,
      label: "微信咨询",
      bg: "bg-white",
      text: "text-charcoal",
      border: "border-warm-stone",
    },
  ];

  return (
    <>
      {/* Desktop sidebar */}
      <div className="hidden lg:flex fixed right-0 top-1/2 -translate-y-1/2 z-40 flex-col border border-warm-stone rounded-l overflow-hidden">
        {items.map((item, i) => (
          <div key={i} className="relative group">
            <a
              href={item.href || "#"}
              className={`flex items-center justify-center w-14 h-14 ${item.bg} ${item.text} border-b border-warm-stone last:border-b-0 transition-all duration-250 hover:bg-charcoal hover:text-white`}
              title={item.label}
            >
              <item.icon size={20} strokeWidth={1.5} />
            </a>
            {/* Tooltip */}
            <div className="absolute right-full top-1/2 -translate-y-1/2 mr-2 px-3 py-1.5 bg-charcoal text-white text-xs whitespace-nowrap rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
              {item.label}
            </div>
          </div>
        ))}
      </div>

      {/* Mobile FAB */}
      <div className="lg:hidden fixed bottom-6 right-6 z-40">
        {mobileOpen && (
          <div className="flex flex-col gap-2 mb-3 animate-in fade-in slide-in-from-bottom-2 duration-200">
            {items.map((item, i) => (
              <a
                key={i}
                href={item.href || "#"}
                className={`flex items-center justify-center w-12 h-12 rounded-full shadow-lg ${item.bg} ${item.text} ${item.border} border`}
                title={item.label}
              >
                <item.icon size={18} strokeWidth={1.5} />
              </a>
            ))}
          </div>
        )}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="w-14 h-14 rounded-full bg-crimson text-white flex items-center justify-center shadow-lg transition-transform duration-200"
        >
          {mobileOpen ? <X size={22} /> : <Plus size={22} />}
        </button>
      </div>
    </>
  );
}
