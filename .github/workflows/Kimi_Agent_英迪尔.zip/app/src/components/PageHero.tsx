import { useEffect, useRef } from "react";
import gsap from "gsap";
import Breadcrumb from "./Breadcrumb";

interface PageHeroProps {
  breadcrumb: { label: string; href?: string }[];
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}

export default function PageHero({
  breadcrumb,
  title,
  subtitle,
  children,
}: PageHeroProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const tl = gsap.timeline();
    tl.from(el.querySelector("h1"), {
      opacity: 0,
      y: 30,
      duration: 0.8,
      ease: "power3.out",
    });
    if (subtitle) {
      tl.from(
        el.querySelector(".subtitle"),
        { opacity: 0, y: 20, duration: 0.6, ease: "power2.out" },
        "-=0.4"
      );
    }
    if (children) {
      tl.from(
        el.querySelector(".hero-children"),
        { opacity: 0, y: 15, duration: 0.5, ease: "power2.out" },
        "-=0.3"
      );
    }

    return () => {
      tl.kill();
    };
  }, [subtitle, children]);

  return (
    <div className="bg-warm-white" ref={containerRef}>
      <div className="content-container pt-36 md:pt-40 pb-12 md:pb-16">
        <Breadcrumb items={breadcrumb} />
        <h1 className="font-serif text-4xl md:text-[52px] font-bold text-charcoal tracking-wide leading-tight">
          {title}
        </h1>
        {subtitle && (
          <p className="subtitle text-lg text-muted-text font-light mt-4">
            {subtitle}
          </p>
        )}
        {children && <div className="hero-children mt-8">{children}</div>}
      </div>
    </div>
  );
}
