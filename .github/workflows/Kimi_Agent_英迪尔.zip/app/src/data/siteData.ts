// Product categories
export const productCategories = [
  { id: "fryer", name: "炸炉系列", nameEn: "Fryer Series" },
  { id: "noodle", name: "煮面炉系列", nameEn: "Noodle Cooker Series" },
  { id: "icecream", name: "冰淇淋机系列", nameEn: "Ice Cream Machine Series" },
  { id: "breading", name: "裹粉台系列", nameEn: "Breading Table Series" },
  { id: "burger", name: "汉堡机系列", nameEn: "Burger Equipment Series" },
  { id: "marinator", name: "腌制机系列", nameEn: "Marinator Series" },
  { id: "oven", name: "链式烤炉/烤箱系列", nameEn: "Conveyor Oven Series" },
  { id: "filter", name: "滤油车系列", nameEn: "Oil Filtration Series" },
  { id: "beverage", name: "冷饮机系列", nameEn: "Beverage Dispenser Series" },
  { id: "griddle", name: "扒炉系列", nameEn: "Griddle Series" },
  { id: "worktable", name: "中心岛/工作台系列", nameEn: "Worktable Series" },
  { id: "warmer", name: "保温柜/保温架系列", nameEn: "Warming Cabinet Series" },
];

// Featured products
export const featuredProducts = [
  {
    id: 1,
    name: "6段单缸带滤油炸炉",
    category: "炸炉系列",
    tags: ["304不锈钢", "一键滤油"],
    features: ["304不锈钢机身", "一键自动滤油", "精准温控系统"],
    image: "/assets/product-fryer-6s1t.jpg",
  },
  {
    id: 2,
    name: "6头变频款升降煮面炉",
    category: "煮面炉系列",
    tags: ["316发热管", "三档变频"],
    features: ["316发热管", "三档变频控制", "自动升降设计"],
    image: "/assets/product-noodle-6head.jpg",
  },
  {
    id: 3,
    name: "立式双缸冰淇淋机",
    category: "冰淇淋机系列",
    tags: ["三头出料", "自动巴氏杀菌"],
    features: ["三头出料设计", "自动巴氏杀菌", "智能触控面板"],
    image: "/assets/product-icecream-vertical.jpg",
  },
  {
    id: 4,
    name: "电脑板真空腌制机",
    category: "腌制机系列",
    tags: ["大批量腌制", "真空锁鲜"],
    features: ["大批量腌制", "真空锁鲜技术", "电脑板精准控制"],
    image: "/assets/product-marinator.jpg",
  },
  {
    id: 5,
    name: "1.5m自动进水陈列保温柜",
    category: "保温柜系列",
    tags: ["双开门可视", "双层置物"],
    features: ["双开门双面可视", "双层置物架", "自动进水系统"],
    image: "/assets/product-warmer-15m.jpg",
  },
  {
    id: 6,
    name: "70cm立式薯条工作站",
    category: "中心岛系列",
    tags: ["双效加热", "双面操作"],
    features: ["双效加热系统", "双面均可操作", "不锈钢机身"],
    image: "/assets/product-fry-station.jpg",
  },
];

// All products
export const allProducts = [
  ...featuredProducts,
  {
    id: 7,
    name: "链式燃气烤炉",
    category: "链式烤炉/烤箱系列",
    tags: ["链条传送", "均匀加热"],
    features: ["链条传送设计", "均匀加热技术", "高效节能"],
    image: "/assets/product-conveyor-oven.jpg",
  },
  {
    id: 8,
    name: "移动滤油车",
    category: "滤油车系列",
    tags: ["移动式设计", "高效过滤"],
    features: ["移动式设计", "高效过滤系统", "大容量储油"],
    image: "/assets/product-oil-cart.jpg",
  },
  {
    id: 9,
    name: "双缸冷饮机",
    category: "冷饮机系列",
    tags: ["双缸双味", "快速制冷"],
    features: ["双缸双味设计", "快速制冷", "透明展示缸"],
    image: "/assets/product-beverage.jpg",
  },
  {
    id: 10,
    name: "商用燃气扒炉",
    category: "扒炉系列",
    tags: ["大面积加热", "独立温控"],
    features: ["大面积加热板", "独立温控", "加厚钢板"],
    image: "/assets/product-griddle.jpg",
  },
  {
    id: 11,
    name: "汉堡机（电热压板）",
    category: "汉堡机系列",
    tags: ["自动压板", "均匀加热"],
    features: ["自动压板设计", "均匀加热", "快速出餐"],
    image: "/assets/product-burger.jpg",
  },
  {
    id: 12,
    name: "1.2m中心岛工作台",
    category: "中心岛/工作台系列",
    tags: ["不锈钢台面", "可定制"],
    features: ["不锈钢台面", "下层储物空间", "可定制化尺寸"],
    image: "/assets/product-worktable.jpg",
  },
];

// News articles
export const newsArticles = [
  {
    id: 1,
    title: "英迪尔荣获2025年度中国商用厨房设备行业领军品牌",
    excerpt: "在近日举行的中国餐饮设备行业峰会上，英迪尔凭借卓越的产品品质和完善的售后服务体系，荣获'2025年度中国商用厨房设备行业领军品牌'称号。",
    category: "英迪尔动态",
    date: "2025-06-02",
    image: "/assets/news-award.jpg",
    featured: true,
  },
  {
    id: 2,
    title: "探索英迪尔自动滤油炸炉的优势，实现完美油炸",
    excerpt: "英迪尔自动滤油炸炉采用一键滤油技术，有效延长食用油使用寿命，确保每次炸制品质如一。",
    category: "英迪尔动态",
    date: "2025-06-01",
    image: "/assets/news-fryer-advantage.jpg",
    featured: false,
  },
  {
    id: 3,
    title: "探索英迪尔自动滤油炸炉为您的厨房带来的优势",
    excerpt: "了解自动滤油炸炉如何帮助连锁餐饮企业降低运营成本，提高出品质量。",
    category: "英迪尔动态",
    date: "2025-05-28",
    image: "/assets/news-fryer-kitchen.jpg",
    featured: false,
  },
  {
    id: 4,
    title: "使用英迪尔自动滤油炸炉，解锁厨房效率",
    excerpt: "智能滤油系统让厨房运营更高效，减少换油频率，提升油炸食品口感一致性。",
    category: "英迪尔动态",
    date: "2025-05-25",
    image: "/assets/news-fryer-efficiency.jpg",
    featured: false,
  },
  {
    id: 5,
    title: "台式商用冰激凌机型号该怎么选择？购买指南",
    excerpt: "越来越多创业者关注台式商用冰激凌机，希望选购合适的设备助力创业之路。",
    category: "行业资讯",
    date: "2025-05-20",
    image: "/assets/news-icecream-guide.jpg",
    featured: false,
  },
  {
    id: 6,
    title: "自动煮面机一台多少钱？选购注意事项全解析",
    excerpt: "自动煮面机是面食店不可或缺的餐饮设备，本文为您详细解析选购要点。",
    category: "行业资讯",
    date: "2025-05-15",
    image: "/assets/news-noodle-price.jpg",
    featured: false,
  },
  {
    id: 7,
    title: "制冰机的正确使用方法指南与维护保养",
    excerpt: "了解制冰机的工作原理和正确使用方法，延长设备使用寿命。",
    category: "常见问题",
    date: "2025-05-10",
    image: "/assets/news-ice-machine.jpg",
    featured: false,
  },
  {
    id: 8,
    title: "商用油炸炉日常保养指南：延长设备使用寿命",
    excerpt: "掌握正确的保养方法，让您的油炸炉保持最佳工作状态。",
    category: "常见问题",
    date: "2025-05-05",
    image: "/assets/news-fryer-maintain.jpg",
    featured: false,
  },
];

// Client brands
export const clientBrands = [
  "海底捞", "塔斯汀", "正新鸡排", "蜜雪冰城", "华莱士",
  "汉堡王", "麦当劳", "德克士", "九毛九", "西贝",
  "喜姐炸串", "黎耀阳糖水", "康师傅", "吉野家", "蒙自源",
];

// Services
export const services = [
  {
    icon: "PencilRuler",
    title: "厨房规划设计",
    description: "专业团队提供连锁餐饮厨房布局规划，优化工作流程与设备配置方案",
  },
  {
    icon: "Wrench",
    title: "设备安装调试",
    description: "全国范围专业安装团队，确保设备快速部署、精准调试、即刻投入使用",
  },
  {
    icon: "Users",
    title: "操作配套培训",
    description: "为门店员工提供系统操作培训，确保设备安全高效运行",
  },
  {
    icon: "ShieldCheck",
    title: "售后维护保障",
    description: "覆盖全国34省的售后网点，7×24小时响应，让您无后顾之忧",
  },
];

// Advantages
export const advantages = [
  {
    icon: "Factory",
    title: "规范厂房",
    description: "拥有上万平方生产基地，提供数百人的服务团队，追求诚信，卓越品质。配备行业先进的激光切割机、数控折弯机等钣金生产设备。",
  },
  {
    icon: "Cog",
    title: "标准车间",
    description: "稳定的产品结构及工艺，先进的生产制造技术，标准5S管理，高效率、高产出。生产管理和质量体系通过ISO体系认证。",
  },
  {
    icon: "Users",
    title: "专业团队",
    description: "优秀的研发团队，专业的技术人才，覆盖全国的售后网点。200+专业人员，其中资深研发人员近30人，具备极强的设计、开发和工艺改进能力。",
  },
  {
    icon: "Truck",
    title: "物流仓储",
    description: "与德邦物流达成战略合作，配备大型仓储保障货源，按时发货准时到达。覆盖全国34个省市自治区，响应更及时。",
  },
];

// Certifications
export const certifications = [
  { name: "ISO 9001", desc: "质量管理体系认证" },
  { name: "ISO 14001", desc: "环境管理体系认证" },
  { name: "CE认证", desc: "欧盟安全认证" },
  { name: "ETL认证", desc: "北美安全认证" },
  { name: "多项发明专利", desc: "自主知识产权" },
];

// Contact info
export const contactInfo = {
  hotline: "400-9933-329",
  afterSales: "400-8035-872",
  email: "info@inidea.net.cn",
  address: "广州市番禺区大龙街开发路3号之三十八",
  wechat: "18319070685",
};

// Nav links
export const navLinks = [
  { label: "首页", href: "/" },
  { label: "产品中心", href: "/products" },
  { label: "关于我们", href: "/about" },
  { label: "新闻资讯", href: "/news" },
  { label: "联系我们", href: "/contact" },
];

// Product detail sample
export const productDetail = {
  id: 1,
  name: "6段单缸带滤油炸炉",
  category: "炸炉系列",
  subtitle: "304不锈钢 · 一键滤油 · 精准温控",
  features: [
    "304食品级不锈钢机身，耐腐蚀易清洁",
    "一键自动滤油系统，延长油品使用寿命",
    "6段精准温控，满足不同食材炸制需求",
    "单缸大容量设计，适合高峰时段连续作业",
    "过热保护装置，确保操作安全",
  ],
  specs: [
    { param: "型号", value: "IND-FRY-6S1T-40L" },
    { param: "电源", value: "380V/50Hz" },
    { param: "功率", value: "12kW" },
    { param: "油缸容量", value: "40L" },
    { param: "温控范围", value: "50°C ~ 200°C" },
    { param: "控温精度", value: "±1°C" },
    { param: "加热方式", value: "电热管加热" },
    { param: "滤油方式", value: "一键自动滤油" },
    { param: "机身材料", value: "304不锈钢" },
    { param: "外形尺寸", value: "400×800×1150mm" },
    { param: "净重", value: "58kg" },
  ],
  featureCards: [
    {
      icon: "Shield",
      title: "304不锈钢机身",
      desc: "全身采用食品级304不锈钢材质，具有优异的耐腐蚀性和耐高温性，确保食品安全，同时易于清洁维护，符合餐饮行业卫生标准。",
    },
    {
      icon: "Droplets",
      title: "一键自动滤油",
      desc: "专利滤油系统设计，仅需一键操作即可完成油品过滤，有效去除油渣和杂质，延长食用油使用寿命30%以上，大幅降低运营成本。",
    },
    {
      icon: "Thermometer",
      title: "6段精准温控",
      desc: "采用进口温控器，6段预设温度满足不同食材炸制需求，控温精度达±1°C，确保每一次出品口感一致，品质稳定。",
    },
    {
      icon: "Flame",
      title: "高效加热系统",
      desc: "12kW大功率电热管，快速升温至设定温度，缩短等待时间。独特的加热管布局确保油温均匀分布，避免局部过热。",
    },
  ],
  images: [
    "/assets/product-fryer-6s1t.jpg",
    "/assets/product-fryer-detail1.jpg",
    "/assets/product-fryer-detail2.jpg",
    "/assets/product-fryer-detail3.jpg",
  ],
};

// News categories
export const newsCategories = ["全部", "英迪尔动态", "行业资讯", "常见问题"];
