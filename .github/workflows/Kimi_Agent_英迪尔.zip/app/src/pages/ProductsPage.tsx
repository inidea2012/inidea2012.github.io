import { useState, useEffect, useRef } from "react";
import { Link } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import PageHero from "../components/PageHero";
import CTABanner from "../components/CTABanner";
import { allProducts, productCategories } from "../data/siteData";

gsap.registerPlugin(ScrollTrigger);

const PAGE_SIZE = 12;

export default function ProductsPage() {
  const [activeFilter, setActiveFilter] = useState("全部");
  const [currentPage, setCurrentPage] = useState(1);
  const gridRef = useRef<HTMLDivElement>(null);

  const filters = [
    "全部",
    ...productCategories.map((c) => c.name),
  ];

  const filteredProducts =
    activeFilter === "全部"
      ? allProducts
      : allProducts.filter((p) => p.category === activeFilter);

  const totalPages = Math.ceil(filteredProducts.length / PAGE_SIZE);
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  useEffect(() => {
    setCurrentPage(1);
  }, [activeFilter]);

  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;

    const cards = el.querySelectorAll(".product-card");
    gsap.set(cards, { opacity: 0, y: 30 });

    const tween = gsap.to(cards, {
      opacity: 1,
      y: 0,
      duration: 0.7,
      stagger: 0.06,
      ease: "power3.out",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        toggleActions: "play none none none",
      },
    });

    return () => {
      tween.kill();
    };
  }, [activeFilter, currentPage]);

  return (
    <>
      <PageHero
        breadcrumb={[{ label: "首页", href: "/" }, { label: "产品中心" }]}
        title="产品中心"
        subtitle="全系列商厨设备，满足连锁餐饮一站式采购需求"
      />

      <section className="bg-white py-12 md:py-16">
        <div className="content-container">
          {/* Filter tabs - horizontal scroll on mobile/tablet */}
          <div className="flex gap-2 overflow-x-auto pb-4 mb-8 scrollbar-hide">
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`shrink-0 px-5 py-2.5 text-[15px] rounded transition-all duration-200 ${
                  activeFilter === filter
                    ? "bg-charcoal text-white"
                    : "text-muted-text hover:bg-light-grey hover:text-charcoal"
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          {/* Product grid */}
          <div
            ref={gridRef}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          >
            {paginatedProducts.map((product) => (
              <Link
                key={product.id}
                to={`/products/${product.id}`}
                className="product-card group bg-white border border-[#F0EDE8] rounded overflow-hidden hover:border-crimson transition-all duration-300"
              >
                <div className="aspect-[3/2] bg-light-grey overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-contain p-3 transition-transform duration-400 group-hover:scale-[1.03]"
                    loading="lazy"
                  />
                </div>
                <div className="p-5">
                  <span className="text-xs text-crimson tracking-wider">
                    {product.category}
                  </span>
                  <h3 className="text-lg font-medium text-charcoal mt-2 group-hover:text-crimson transition-colors">
                    {product.name}
                  </h3>
                  <ul className="mt-3 space-y-1">
                    {product.features.slice(0, 3).map((f) => (
                      <li
                        key={f}
                        className="text-sm text-muted-text font-light"
                      >
                        · {f}
                      </li>
                    ))}
                  </ul>
                  <span className="inline-flex items-center gap-1 text-sm text-crimson mt-4">
                    了解详情 <ArrowRight size={14} />
                  </span>
                </div>
              </Link>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-12">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="w-10 h-10 flex items-center justify-center border border-[#F0EDE8] rounded text-muted-text hover:bg-light-grey disabled:opacity-30 transition-colors"
              >
                <ChevronLeft size={16} />
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`w-10 h-10 flex items-center justify-center rounded text-sm transition-colors ${
                      currentPage === page
                        ? "bg-charcoal text-white"
                        : "border border-[#F0EDE8] text-muted-text hover:bg-light-grey"
                    }`}
                  >
                    {page}
                  </button>
                )
              )}
              <button
                onClick={() =>
                  setCurrentPage((p) => Math.min(totalPages, p + 1))
                }
                disabled={currentPage === totalPages}
                className="w-10 h-10 flex items-center justify-center border border-[#F0EDE8] rounded text-muted-text hover:bg-light-grey disabled:opacity-30 transition-colors"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          )}
        </div>
      </section>

      <CTABanner />
    </>
  );
}
