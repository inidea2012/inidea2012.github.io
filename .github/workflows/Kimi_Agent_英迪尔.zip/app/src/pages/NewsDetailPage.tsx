import { useEffect, useRef } from "react";
import { Link, useParams } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  Calendar,
  Tag,
  User,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { newsArticles } from "../data/siteData";
import CTABanner from "../components/CTABanner";

gsap.registerPlugin(ScrollTrigger);

export default function NewsDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const articleId = parseInt(slug || "1");
  const article = newsArticles.find((a) => a.id === articleId) || newsArticles[0];
  const bodyRef = useRef<HTMLDivElement>(null);

  const currentIndex = newsArticles.findIndex((a) => a.id === article.id);
  const prevArticle = currentIndex > 0 ? newsArticles[currentIndex - 1] : null;
  const nextArticle =
    currentIndex < newsArticles.length - 1
      ? newsArticles[currentIndex + 1]
      : null;
  const relatedArticles = newsArticles
    .filter((a) => a.id !== article.id)
    .slice(0, 3);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  useEffect(() => {
    const el = bodyRef.current;
    if (!el) return;

    const paragraphs = el.querySelectorAll("p, h2, ul");
    gsap.set(paragraphs, { opacity: 0, y: 15 });
    gsap.to(paragraphs, {
      opacity: 1,
      y: 0,
      duration: 0.6,
      stagger: 0.05,
      ease: "power2.out",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        toggleActions: "play none none none",
      },
    });
  }, [article.id]);

  return (
    <>
      {/* Article Header */}
      <div className="bg-white pt-32 md:pt-36 pb-10">
        <div className="max-w-[800px] mx-auto px-6 md:px-10">
          <nav className="text-[13px] text-muted-text font-light mb-6">
            <Link to="/" className="hover:text-crimson transition-colors">
              首页
            </Link>
            <span className="mx-2">/</span>
            <Link to="/news" className="hover:text-crimson transition-colors">
              新闻资讯
            </Link>
            <span className="mx-2">/</span>
            <span>{article.category}</span>
          </nav>

          <span className="text-xs text-crimson tracking-wider">
            {article.category}
          </span>
          <h1 className="font-serif text-3xl md:text-[42px] font-bold text-charcoal leading-tight tracking-wide mt-4">
            {article.title}
          </h1>

          <div className="flex flex-wrap items-center gap-6 mt-6 text-sm text-muted-text">
            <span className="flex items-center gap-2">
              <Calendar size={14} />
              {article.date}
            </span>
            <span className="flex items-center gap-2">
              <Tag size={14} />
              {article.category}
            </span>
            <span className="flex items-center gap-2">
              <User size={14} />
              英迪尔编辑部
            </span>
          </div>

          <div className="aspect-video rounded overflow-hidden bg-light-grey mt-8">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
          </div>
          <p className="text-[13px] text-muted-text font-light italic text-center mt-3">
            {article.title}
          </p>
        </div>
      </div>

      {/* Article Body */}
      <div className="bg-white pb-12">
        <div
          ref={bodyRef}
          className="max-w-[800px] mx-auto px-6 md:px-10"
        >
          <p className="text-[17px] text-charcoal font-normal leading-[1.9] mb-6">
            {article.excerpt}在连锁餐饮行业，油炸设备的品质直接关系到菜品的口感和食品安全。英迪尔自动滤油炸炉凭借其卓越的性能和人性化设计，已成为众多知名连锁餐饮品牌的首选设备。
          </p>

          <h2 className="text-2xl md:text-[28px] font-serif font-medium text-charcoal mt-12 mb-5">
            自动滤油技术的核心优势
          </h2>

          <h3 className="text-xl md:text-[22px] font-medium text-charcoal mt-8 mb-4">
            延长食用油使用寿命
          </h3>
          <p className="text-[17px] text-charcoal font-normal leading-[1.9] mb-6">
            传统油炸设备在使用一段时间后，油渣和食物残渣会不断积累，导致食用油品质下降，需要频繁更换。英迪尔自动滤油炸炉采用专利滤油系统，一键操作即可完成油品过滤，有效去除油渣和杂质，可将食用油使用寿命延长30%以上，大幅降低运营成本。
          </p>
          <ul className="text-[17px] text-charcoal font-normal leading-[2] ml-6 space-y-1 mb-8">
            <li>· 一键自动滤油，操作简便</li>
            <li>· 高效过滤系统，去除微小颗粒</li>
            <li>· 减少换油频率，降低原料成本</li>
          </ul>

          <h3 className="text-xl md:text-[22px] font-medium text-charcoal mt-8 mb-4">
            提升油炸食品品质一致性
          </h3>
          <p className="text-[17px] text-charcoal font-normal leading-[1.9] mb-6">
            清洁的油品是油炸食品口感和外观的关键。通过定期滤油，英迪尔炸炉能够保持油品清澈透明，炸制出的食物色泽金黄、口感酥脆，确保每一家门店的出品品质始终如一。
          </p>

          <blockquote className="border-l-[3px] border-crimson pl-6 my-10 py-2">
            <p className="font-serif text-lg text-charcoal italic font-medium leading-relaxed">
              "自从使用了英迪尔的自动滤油炸炉，我们门店的用油成本降低了近25%，而且顾客对炸鸡口感的满意度明显提升。"
            </p>
            <p className="text-sm text-muted-text mt-3">
              —— 某知名连锁炸鸡品牌运营总监
            </p>
          </blockquote>

          <h2 className="text-2xl md:text-[28px] font-serif font-medium text-charcoal mt-12 mb-5">
            英迪尔滤油炸炉的技术亮点
          </h2>
          <ul className="text-[17px] text-charcoal font-normal leading-[2] ml-6 space-y-1 mb-8">
            <li>· 304食品级不锈钢机身，耐腐蚀、易清洁</li>
            <li>· 6段精准温控，控温精度±1°C</li>
            <li>· 一键自动滤油，操作便捷</li>
            <li>· 过热保护装置，确保使用安全</li>
            <li>· 大容量设计，适合高峰时段连续作业</li>
          </ul>

          <h2 className="text-2xl md:text-[28px] font-serif font-medium text-charcoal mt-12 mb-5">
            如何选购适合您的滤油炸炉
          </h2>
          <p className="text-[17px] text-charcoal font-normal leading-[1.9] mb-6">
            在选择滤油炸炉时，建议您综合考虑门店规模、日均客流量、菜单品类等因素。英迪尔提供多种规格和配置的炸炉产品，满足不同场景的需求。您可以联系我们的专业顾问，获取针对性的设备配置方案。
          </p>

          {/* Tags */}
          <div className="border-t border-[#F0EDE8] pt-8 mt-12">
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-sm text-muted-text">标签：</span>
              {["炸炉", "滤油", "连锁餐饮", "厨房设备"].map((tag) => (
                <span
                  key={tag}
                  className="text-[13px] text-muted-text bg-light-grey px-4 py-1.5 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Article Navigation */}
      <div className="bg-warm-white">
        <div className="max-w-[800px] mx-auto px-6 md:px-10 py-10 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {prevArticle && (
              <Link
                to={`/news/${prevArticle.id}`}
                className="bg-white border border-[#F0EDE8] rounded p-6 group hover:border-crimson transition-colors"
              >
                <span className="text-[13px] text-muted-text font-light flex items-center gap-1">
                  <ChevronLeft size={14} /> 上一篇
                </span>
                <p className="text-base font-medium text-charcoal mt-2 line-clamp-2 group-hover:text-crimson transition-colors">
                  {prevArticle.title}
                </p>
              </Link>
            )}
            {nextArticle && (
              <Link
                to={`/news/${nextArticle.id}`}
                className={`bg-white border border-[#F0EDE8] rounded p-6 group hover:border-crimson transition-colors ${
                  !prevArticle ? "md:col-start-2" : ""
                }`}
              >
                <span className="text-[13px] text-muted-text font-light flex items-center gap-1 justify-end">
                  下一篇 <ChevronRight size={14} />
                </span>
                <p className="text-base font-medium text-charcoal mt-2 line-clamp-2 group-hover:text-crimson transition-colors text-right">
                  {nextArticle.title}
                </p>
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Related Articles */}
      <div className="bg-white py-12 md:py-16">
        <div className="content-container">
          <h3 className="text-2xl font-light text-charcoal mb-8">相关文章</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {relatedArticles.map((a) => (
              <Link key={a.id} to={`/news/${a.id}`} className="group">
                <div className="aspect-[16/10] rounded overflow-hidden bg-light-grey">
                  <img
                    src={a.image}
                    alt={a.title}
                    className="w-full h-full object-cover transition-transform duration-400 group-hover:scale-[1.03]"
                    loading="lazy"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                </div>
                <div className="mt-4">
                  <span className="text-xs text-crimson">{a.category}</span>
                  <div className="flex items-center gap-2 mt-2 text-[13px] text-muted-text">
                    <Calendar size={14} />
                    {a.date}
                  </div>
                  <h4 className="text-base font-medium text-charcoal mt-2 line-clamp-2 group-hover:text-crimson transition-colors">
                    {a.title}
                  </h4>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <CTABanner mini />
    </>
  );
}
