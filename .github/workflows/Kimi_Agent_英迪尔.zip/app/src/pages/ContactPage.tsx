import { useState, useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  Phone,
  Wrench,
  Mail,
  MapPin,
  MessageCircle,
  Headset,
  FileText,
} from "lucide-react";
import PageHero from "../components/PageHero";
import { contactInfo } from "../data/siteData";

gsap.registerPlugin(ScrollTrigger);

export default function ContactPage() {
  const [formState, setFormState] = useState<
    "idle" | "submitting" | "success"
  >("idle");
  const formRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = formRef.current;
    if (!el) return;

    gsap.set(el.querySelectorAll("[data-contact-animate]"), {
      opacity: 0,
      y: 25,
    });
    gsap.to(el.querySelectorAll("[data-contact-animate]"), {
      opacity: 1,
      y: 0,
      duration: 0.8,
      stagger: 0.15,
      ease: "power3.out",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        toggleActions: "play none none none",
      },
    });
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormState("submitting");
    setTimeout(() => setFormState("success"), 1500);
  };

  const contactItems = [
    {
      icon: Phone,
      label: "全国服务热线",
      value: contactInfo.hotline,
      sub: "工作日 9:00-18:00",
      href: `tel:${contactInfo.hotline}`,
    },
    {
      icon: Wrench,
      label: "售后热线",
      value: contactInfo.afterSales,
      sub: "7×24小时服务",
      href: `tel:${contactInfo.afterSales}`,
    },
    {
      icon: Mail,
      label: "电子邮箱",
      value: contactInfo.email,
      sub: "我们将在24小时内回复",
      href: `mailto:${contactInfo.email}`,
    },
    {
      icon: MapPin,
      label: "公司地址",
      value: contactInfo.address,
      sub: "欢迎莅临参观考察",
    },
    {
      icon: MessageCircle,
      label: "微信咨询",
      value: contactInfo.wechat,
      sub: "扫码添加微信客服",
    },
  ];

  const serviceChannels = [
    {
      icon: Headset,
      title: "售前咨询",
      desc: "产品选型、厨房规划、方案报价，专业顾问一对一服务",
      phone: contactInfo.hotline,
    },
    {
      icon: Wrench,
      title: "售后支持",
      desc: "设备安装、操作培训、故障维修，全国网点快速响应",
      phone: contactInfo.afterSales,
    },
    {
      icon: FileText,
      title: "技术服务",
      desc: "设备定制、技术咨询、配件供应，工程师全程支持",
      phone: contactInfo.hotline,
    },
  ];

  return (
    <>
      <PageHero
        breadcrumb={[{ label: "首页", href: "/" }, { label: "联系我们" }]}
        title="联系我们"
        subtitle="无论您有任何需求，英迪尔团队随时为您服务"
      />

      {/* Contact Form + Info */}
      <section className="bg-white py-12 md:py-20" ref={formRef}>
        <div className="content-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16">
            {/* Form */}
            <div data-contact-animate>
              <h3 className="text-xl md:text-[22px] font-medium text-charcoal mb-8">
                留下您的信息，我们将安排专人与您联系
              </h3>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="text-sm text-charcoal font-normal mb-2 block">
                    姓名 <span className="text-crimson">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="请输入您的姓名"
                    className="w-full h-12 border border-warm-stone rounded px-4 text-[15px] focus:border-crimson focus:ring-2 focus:ring-crimson/10 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="text-sm text-charcoal font-normal mb-2 block">
                    邮箱 <span className="text-crimson">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="请输入您的邮箱"
                    className="w-full h-12 border border-warm-stone rounded px-4 text-[15px] focus:border-crimson focus:ring-2 focus:ring-crimson/10 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="text-sm text-charcoal font-normal mb-2 block">
                    电话号码 <span className="text-crimson">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="请输入您的电话号码"
                    className="w-full h-12 border border-warm-stone rounded px-4 text-[15px] focus:border-crimson focus:ring-2 focus:ring-crimson/10 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="text-sm text-charcoal font-normal mb-2 block">
                    公司名称
                  </label>
                  <input
                    type="text"
                    placeholder="请输入您的公司名称（选填）"
                    className="w-full h-12 border border-warm-stone rounded px-4 text-[15px] focus:border-crimson focus:ring-2 focus:ring-crimson/10 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="text-sm text-charcoal font-normal mb-2 block">
                    需求描述 <span className="text-crimson">*</span>
                  </label>
                  <textarea
                    required
                    rows={5}
                    placeholder="请简要描述您的设备需求，如门店数量、厨房面积、所需设备等"
                    className="w-full border border-warm-stone rounded p-4 text-[15px] focus:border-crimson focus:ring-2 focus:ring-crimson/10 outline-none transition-all resize-y"
                  />
                </div>
                <button
                  type="submit"
                  disabled={formState !== "idle"}
                  className={`w-full h-[52px] rounded text-base font-medium text-white transition-all duration-300 ${
                    formState === "success"
                      ? "bg-green-600"
                      : "bg-crimson hover:brightness-110"
                  } disabled:opacity-70`}
                >
                  {formState === "idle" && "立即提交"}
                  {formState === "submitting" && "提交中..."}
                  {formState === "success" && "提交成功！"}
                </button>
              </form>
            </div>

            {/* Contact Info Panel */}
            <div data-contact-animate>
              <div className="bg-warm-white rounded p-8 md:p-10">
                <h3 className="text-xl font-medium text-charcoal mb-8">
                  直接联系我们
                </h3>
                <div className="space-y-7">
                  {contactItems.map((item) => (
                    <a
                      key={item.label}
                      href={item.href}
                      className="flex items-start gap-4 group"
                    >
                      <div className="w-10 h-10 rounded-full bg-crimson/10 flex items-center justify-center shrink-0">
                        <item.icon size={20} className="text-crimson" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-text">{item.label}</p>
                        <p className="text-lg md:text-xl font-medium text-charcoal mt-1">
                          {item.value}
                        </p>
                        <p className="text-[13px] text-muted-text font-light mt-1">
                          {item.sub}
                        </p>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map */}
      <section className="relative h-[280px] md:h-[400px] overflow-hidden">
        <img
          src="/assets/map-guangzhou.jpg"
          alt="广州市番禺区"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 via-transparent to-transparent" />
        <div className="absolute bottom-6 left-6 md:bottom-8 md:left-10">
          <p className="text-white text-base font-normal">
            {contactInfo.address}
          </p>
          <p className="text-white/60 text-sm font-light mt-1">
            英迪尔电器有限公司
          </p>
        </div>
      </section>

      {/* Service Channels */}
      <section className="bg-warm-white py-12 md:py-16">
        <div className="content-container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {serviceChannels.map((channel) => (
              <div
                key={channel.title}
                className="bg-white rounded p-8 md:p-10 text-center"
              >
                <channel.icon
                  size={48}
                  strokeWidth={1.5}
                  className="text-charcoal mx-auto"
                />
                <h4 className="text-xl font-medium text-charcoal mt-5">
                  {channel.title}
                </h4>
                <p className="text-[15px] text-muted-text font-light leading-relaxed mt-3">
                  {channel.desc}
                </p>
                <p className="text-lg font-medium text-crimson mt-4">
                  {channel.phone}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
