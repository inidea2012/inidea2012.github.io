import { useEffect, useRef } from "react";
import { Link } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  ArrowRight,
  PencilRuler,
  Wrench,
  Users,
  ShieldCheck,
  Calendar,
} from "lucide-react";
import {
  productCategories,
  featuredProducts,
  clientBrands,
  services,
  newsArticles,
} from "../data/siteData";
import CTABanner from "../components/CTABanner";
import { useCountUp } from "../hooks/useCountUp";

gsap.registerPlugin(ScrollTrigger);

/* ─── Hero Section ─── */
function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;

    const tl = gsap.timeline();
    tl.from(el.querySelector(".hero-bg"), {
      opacity: 0,
      scale: 1.05,
      duration: 1.5,
      ease: "power2.out",
    })
      .from(
        el.querySelectorAll(".hero-line"),
        {
          opacity: 0,
          y: 80,
          duration: 1,
          stagger: 0.15,
          ease: "power3.out",
        },
        "-=0.8"
      )
      .from(
        el.querySelector(".hero-sub"),
        { opacity: 0, y: 20, duration: 0.8, ease: "power2.out" },
        "-=0.4"
      )
      .from(
        el.querySelector(".hero-cta"),
        { opacity: 0, y: 15, duration: 0.6, ease: "power2.out" },
        "-=0.3"
      )
      .from(
        el.querySelector(".hero-scroll"),
        { opacity: 0, duration: 0.5 },
        "-=0.1"
      );

    return () => {
      tl.kill();
    };
  }, []);

  return (
    <section
      ref={heroRef}
      className="relative min-h-[100dvh] flex items-center overflow-hidden"
    >
      {/* Background */}
      <div className="hero-bg absolute inset-0">
        <img
          src="/assets/hero-bg.jpg"
          alt="Commercial kitchen"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal/30 via-charcoal/70 to-charcoal/95" />
      </div>

      {/* Content */}
      <div className="relative z-10 content-container w-full py-32">
        <h1 className="font-serif text-white">
          <span className="hero-line block text-5xl md:text-7xl lg:text-[80px] font-bold tracking-[0.08em] leading-tight">
            万店之选
          </span>
          <span className="hero-line block text-3xl md:text-5xl lg:text-[48px] font-medium tracking-[0.04em] mt-2">
            智厨{" "}
            <span className="text-crimson">Equipment</span>
          </span>
        </h1>
        <p className="hero-sub mt-6 text-lg md:text-xl text-white/70 font-light tracking-[0.06em]">
          英迪尔 · 专注连锁餐饮厨房设备14年
        </p>
        <Link
          to="/products"
          className="hero-cta inline-block mt-8 px-9 py-3.5 border border-white text-white text-[15px] font-normal tracking-wider hover:bg-white hover:text-charcoal transition-all duration-300"
        >
          探索我们的产品
        </Link>
      </div>

      {/* Scroll indicator */}
      <div className="hero-scroll absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50">
        <div className="w-[1px] h-10 bg-white animate-pulse" />
      </div>
    </section>
  );
}

/* ─── Product Categories ─── */
function ProductCategories() {
  const ref = useScrollSection();

  return (
    <section className="bg-white section-padding" ref={ref}>
      <div className="content-container">
        <div className="text-center mb-12 md:mb-16">
          <span className="text-[13px] text-muted-text tracking-[0.15em] font-light uppercase">
            PRODUCTS
          </span>
          <h2 className="text-3xl md:text-[44px] font-light text-charcoal tracking-wide mt-3">
            全系列产品矩阵
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {productCategories.map((cat) => (
            <Link
              key={cat.id}
              to="/products"
              className="group relative aspect-[4/3] rounded overflow-hidden bg-light-grey"
            >
              <img
                src={`/assets/product-${cat.id === "oven" ? "conveyor-oven" : cat.id === "filter" ? "oil-cart" : cat.id === "beverage" ? "beverage" : cat.id === "griddle" ? "griddle" : cat.id === "burger" ? "burger" : cat.id === "worktable" ? "worktable" : cat.id === "warmer" ? "warmer-15m" : cat.id === "breading" ? "marinator" : cat.id === "fryer" ? "fryer-6s1t" : cat.id === "noodle" ? "noodle-6head" : cat.id === "icecream" ? "icecream-vertical" : "fry-station"}.jpg`}
                alt={cat.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/70 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <span className="text-white text-base md:text-lg font-medium">
                  {cat.name}
                </span>
              </div>
              {/* Hover overlay */}
              <div className="absolute inset-0 bg-charcoal/50 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-400">
                <span className="text-white text-lg md:text-xl font-medium">
                  {cat.name}
                </span>
                <span className="text-crimson text-sm mt-2 flex items-center gap-1">
                  查看产品 <ArrowRight size={14} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Featured Products ─── */
function FeaturedProducts() {
  const ref = useScrollSection();

  return (
    <section className="bg-cream section-padding" ref={ref}>
      <div className="content-container">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-10 md:mb-14">
          <div>
            <span className="text-[13px] text-muted-text tracking-[0.15em] font-light uppercase">
              BEST SELLERS
            </span>
            <h2 className="text-3xl md:text-[44px] font-light text-charcoal tracking-wide mt-3">
              热销产品推荐
            </h2>
            <p className="text-base text-muted-text font-light mt-3">
              英迪尔核心产品，经1000+连锁品牌验证
            </p>
          </div>
          <Link
            to="/products"
            className="text-sm text-crimson mt-4 md:mt-0 flex items-center gap-1 hover:underline"
          >
            查看全部 <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {featuredProducts.map((product) => (
            <Link
              key={product.id}
              to={`/products/${product.id}`}
              className="group bg-white rounded overflow-hidden transition-all duration-400 hover:-translate-y-1 hover:shadow-lg"
            >
              <div className="aspect-[3/2] bg-light-grey overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-contain p-4 transition-transform duration-400 group-hover:scale-[1.03]"
                  loading="lazy"
                />
              </div>
              <div className="p-5 md:p-6">
                <div className="flex flex-wrap gap-2 mb-3">
                  {product.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-xs text-muted-text bg-charcoal/5 px-3 py-1 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <h3 className="text-lg font-medium text-charcoal group-hover:text-crimson transition-colors">
                  {product.name}
                </h3>
                <span className="inline-flex items-center gap-1 text-sm text-crimson mt-3">
                  查看产品 <ArrowRight size={14} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Brand Trust ─── */
function BrandTrust() {
  const { ref: countRef, displayValue } = useCountUp(300, 1.5, "+");
  const sectionRef = useScrollSection();

  return (
    <section className="bg-white section-padding" ref={sectionRef}>
      <div className="content-container">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Stats */}
          <div className="lg:col-span-2">
            <div ref={countRef}>
              <span className="text-7xl md:text-[120px] font-bold text-crimson leading-none tracking-tight">
                {displayValue}
              </span>
            </div>
            <h3 className="text-2xl md:text-4xl font-light text-charcoal mt-4">
              品牌信赖之选
            </h3>
            <p className="text-base text-muted-text font-light leading-relaxed mt-6 max-w-[420px]">
              英迪尔深耕连锁餐饮设备14年，服务海底捞、塔斯汀、正新鸡排、蜜雪冰城、华莱士、汉堡王等头部品牌，品质经市场验证。集研发、生产、销售、售后于一体，服务网络遍布全国34个省市自治区。
            </p>
            <Link
              to="/about"
              className="inline-flex items-center gap-1 text-sm text-crimson mt-8 hover:underline"
            >
              了解更多 <ArrowRight size={14} />
            </Link>
          </div>

          {/* Client logos */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-[1px] bg-warm-stone/30">
              {clientBrands.map((brand) => (
                <div
                  key={brand}
                  className="bg-white h-20 flex items-center justify-center px-3 hover:bg-warm-white transition-colors duration-300"
                >
                  <span className="text-[13px] text-muted-text font-normal text-center">
                    {brand}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── Services ─── */
function OneStopServices() {
  const ref = useScrollSection();
  const iconMap: Record<string, React.ElementType> = {
    PencilRuler,
    Wrench,
    Users,
    ShieldCheck,
  };

  return (
    <section className="bg-warm-white section-padding" ref={ref}>
      <div className="content-container">
        <div className="text-center mb-12 md:mb-16">
          <span className="text-[13px] text-muted-text tracking-[0.15em] font-light uppercase">
            SERVICES
          </span>
          <h2 className="text-3xl md:text-[44px] font-light text-charcoal tracking-wide mt-3">
            一站式设备配套服务
          </h2>
          <p className="text-base text-muted-text font-light mt-3">
            从厨房规划到售后维护，全程专业支持
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-10">
          {services.map((service) => {
            const Icon = iconMap[service.icon];
            return (
              <div key={service.title} className="text-center group">
                <div className="w-20 h-20 rounded-full border border-warm-stone flex items-center justify-center mx-auto transition-colors duration-300 group-hover:border-crimson">
                  <Icon
                    size={32}
                    strokeWidth={1.5}
                    className="text-charcoal transition-colors duration-300 group-hover:text-crimson"
                  />
                </div>
                <h3 className="text-xl font-medium text-charcoal mt-6">
                  {service.title}
                </h3>
                <p className="text-[15px] text-muted-text font-light leading-relaxed mt-3 max-w-[260px] mx-auto">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ─── About Preview ─── */
function AboutPreview() {
  const ref = useScrollSection();
  const yearCount = useCountUp(2012, 1.5, "");
  const staffCount = useCountUp(200, 1.5, "+");
  const clientCount = useCountUp(1000, 1.5, "+");

  return (
    <section className="bg-cream section-padding" ref={ref}>
      <div className="content-container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Stats */}
          <div>
            <span className="text-[13px] text-muted-text tracking-[0.15em] font-light uppercase">
              SINCE 2012
            </span>
            <div className="mt-8 space-y-10">
              <div ref={yearCount.ref}>
                <span className="text-5xl md:text-6xl font-bold text-crimson">
                  {yearCount.displayValue}
                </span>
                <p className="text-base text-charcoal font-normal mt-2">
                  成立时间
                </p>
              </div>
              <div ref={staffCount.ref}>
                <span className="text-5xl md:text-6xl font-bold text-crimson">
                  {staffCount.displayValue}
                </span>
                <p className="text-base text-charcoal font-normal mt-2">
                  专业人员
                </p>
              </div>
              <div ref={clientCount.ref}>
                <span className="text-5xl md:text-6xl font-bold text-crimson">
                  {clientCount.displayValue}
                </span>
                <p className="text-base text-charcoal font-normal mt-2">
                  连锁餐饮客户
                </p>
              </div>
            </div>
          </div>

          {/* Narrative */}
          <div>
            <h2 className="font-serif text-3xl md:text-4xl font-medium text-charcoal">
              走进英迪尔
            </h2>
            <div className="mt-6 space-y-4 text-base text-charcoal font-light leading-relaxed">
              <p>
                英迪尔电器有限公司成立于2012年11月，位于广州市番禺区，是一家专业从事餐饮设备研发、生产、销售和服务的大型企业。公司占地面积超过10,000㎡，建筑面积15,000㎡。
              </p>
              <p>
                英迪尔拥有一支200多人的专业团队，其中行业资深的研发人员近30人，在餐饮设备领域具备极强的设计、开发、工艺和改进能力，并取得了多项产品专利和认证资质。
              </p>
              <p>
                公司厂房符合高标准厂房的设计要求，配备了行业先进的激光切割机、数控折弯机等钣金生产设备，生产管理和质量体系通过了ISO体系的认证，制造加工能力在国内首屈一指！
              </p>
            </div>
            <Link
              to="/about"
              className="inline-flex items-center gap-1 text-sm text-crimson mt-8 hover:underline"
            >
              了解更多 <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── News Preview ─── */
function NewsPreview() {
  const ref = useScrollSection();
  const previewArticles = newsArticles.filter((a) => !a.featured).slice(0, 3);

  return (
    <section className="bg-white section-padding" ref={ref}>
      <div className="content-container">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-10 md:mb-14">
          <div>
            <span className="text-[13px] text-muted-text tracking-[0.15em] font-light uppercase">
              NEWS
            </span>
            <h2 className="text-3xl md:text-[44px] font-light text-charcoal tracking-wide mt-3">
              最新资讯
            </h2>
          </div>
          <Link
            to="/news"
            className="text-sm text-crimson mt-4 md:mt-0 flex items-center gap-1 hover:underline"
          >
            查看全部 <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {previewArticles.map((article) => (
            <Link
              key={article.id}
              to={`/news/${article.id}`}
              className="group"
            >
              <div className="aspect-[16/10] rounded overflow-hidden bg-light-grey">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-400 group-hover:scale-[1.03]"
                  loading="lazy"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = "none";
                  }}
                />
              </div>
              <div className="mt-5">
                <span className="text-xs text-crimson tracking-wider">
                  {article.category}
                </span>
                <div className="flex items-center gap-2 mt-2 text-[13px] text-muted-text">
                  <Calendar size={14} />
                  {article.date}
                </div>
                <h3 className="text-lg font-medium text-charcoal mt-3 leading-snug line-clamp-2 group-hover:text-crimson transition-colors">
                  {article.title}
                </h3>
                <span className="inline-flex items-center gap-1 text-sm text-crimson mt-4">
                  阅读全文 <ArrowRight size={14} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Scroll animation helper ─── */
function useScrollSection() {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const items = el.querySelectorAll("[data-scroll-item]");
    const targets = items.length > 0 ? items : [el];

    gsap.set(targets, { opacity: 0, y: 40 });

    const tween = gsap.to(targets, {
      opacity: 1,
      y: 0,
      duration: 0.8,
      stagger: 0.1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        toggleActions: "play none none none",
      },
    });

    return () => {
      tween.kill();
    };
  }, []);

  return ref;
}

/* ─── Main Page ─── */
export default function HomePage() {
  return (
    <>
      <HeroSection />
      <ProductCategories />
      <FeaturedProducts />
      <BrandTrust />
      <OneStopServices />
      <AboutPreview />
      <NewsPreview />
      <CTABanner />
    </>
  );
}
