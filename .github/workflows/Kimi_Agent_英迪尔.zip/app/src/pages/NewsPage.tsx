import { useState, useEffect, useRef } from "react";
import { Link } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight, Calendar } from "lucide-react";
import PageHero from "../components/PageHero";
import CTABanner from "../components/CTABanner";
import { newsArticles, newsCategories } from "../data/siteData";

gsap.registerPlugin(ScrollTrigger);

export default function NewsPage() {
  const [activeCategory, setActiveCategory] = useState("全部");
  const gridRef = useRef<HTMLDivElement>(null);

  const filtered =
    activeCategory === "全部"
      ? newsArticles
      : newsArticles.filter((a) => a.category === activeCategory);

  const featured = filtered.find((a) => a.featured) || filtered[0];
  const rest = filtered.filter((a) => a.id !== featured?.id);

  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;

    const cards = el.querySelectorAll(".news-card");
    gsap.set(cards, { opacity: 0, y: 25 });
    gsap.to(cards, {
      opacity: 1,
      y: 0,
      duration: 0.7,
      stagger: 0.1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        toggleActions: "play none none none",
      },
    });
  }, [activeCategory]);

  return (
    <>
      <PageHero
        breadcrumb={[{ label: "首页", href: "/" }, { label: "新闻资讯" }]}
        title="新闻资讯"
        subtitle="了解英迪尔最新动态与行业趋势"
      >
        {/* Category tabs */}
        <div className="flex gap-1 overflow-x-auto pb-2">
          {newsCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`shrink-0 px-5 py-2.5 text-[15px] transition-all duration-200 border-b-2 ${
                activeCategory === cat
                  ? "text-charcoal border-crimson"
                  : "text-muted-text border-transparent hover:text-charcoal"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </PageHero>

      <section className="bg-white py-10 md:py-16">
        <div className="content-container">
          {/* Featured Article */}
          {featured && (
            <div className="border-b border-[#F0EDE8] pb-10 md:pb-12 mb-10 md:mb-12">
              <Link
                to={`/news/${featured.id}`}
                className="grid grid-cols-1 lg:grid-cols-5 gap-6 lg:gap-10 group"
              >
                <div className="lg:col-span-3 aspect-video rounded overflow-hidden bg-light-grey">
                  <img
                    src={featured.image}
                    alt={featured.title}
                    className="w-full h-full object-cover transition-transform duration-400 group-hover:scale-[1.02]"
                    loading="lazy"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                </div>
                <div className="lg:col-span-2 flex flex-col justify-center py-4">
                  <span className="text-xs text-crimson tracking-wider">
                    {featured.category}
                  </span>
                  <div className="flex items-center gap-2 mt-3 text-sm text-muted-text">
                    <Calendar size={14} />
                    {featured.date}
                  </div>
                  <h3 className="text-2xl md:text-[28px] font-medium text-charcoal leading-snug mt-4 group-hover:text-crimson transition-colors">
                    {featured.title}
                  </h3>
                  <p className="text-base text-muted-text font-light leading-relaxed mt-4 line-clamp-3">
                    {featured.excerpt}
                  </p>
                  <span className="inline-flex items-center gap-1 text-sm text-crimson mt-6">
                    阅读全文 <ArrowRight size={14} />
                  </span>
                </div>
              </Link>
            </div>
          )}

          {/* Article Grid */}
          <div
            ref={gridRef}
            className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10"
          >
            {rest.map((article) => (
              <Link
                key={article.id}
                to={`/news/${article.id}`}
                className="news-card group"
              >
                <div className="aspect-[16/10] rounded overflow-hidden bg-light-grey">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover transition-transform duration-400 group-hover:scale-[1.03]"
                    loading="lazy"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                </div>
                <div className="mt-5">
                  <span className="text-xs text-crimson tracking-wider">
                    {article.category}
                  </span>
                  <div className="flex items-center gap-2 mt-2 text-[13px] text-muted-text">
                    <Calendar size={14} />
                    {article.date}
                  </div>
                  <h3 className="text-xl font-medium text-charcoal mt-3 leading-snug line-clamp-2 group-hover:text-crimson transition-colors">
                    {article.title}
                  </h3>
                  <span className="inline-flex items-center gap-1 text-sm text-crimson mt-4">
                    阅读全文 <ArrowRight size={14} />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CTABanner />
    </>
  );
}
