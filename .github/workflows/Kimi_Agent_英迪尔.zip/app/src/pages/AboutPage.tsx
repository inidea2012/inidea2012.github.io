import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Factory, Cog, Users, Truck, Award } from "lucide-react";
import PageHero from "../components/PageHero";
import CTABanner from "../components/CTABanner";
import { advantages, certifications } from "../data/siteData";
import { useCountUp } from "../hooks/useCountUp";

gsap.registerPlugin(ScrollTrigger);

const advantageIcons: Record<string, React.ElementType> = {
  Factory,
  Cog,
  Users,
  Truck,
};

export default function AboutPage() {
  const storyRef = useRef<HTMLDivElement>(null);
  const advRef = useRef<HTMLDivElement>(null);
  const certRef = useRef<HTMLDivElement>(null);

  const yearCount = useCountUp(2012, 1.5, "");
  const staffCount = useCountUp(200, 1.5, "+");
  const clientCount = useCountUp(1000, 1.5, "+");
  const areaCount = useCountUp(10000, 1.5, "");

  useEffect(() => {
    [storyRef, advRef, certRef].forEach((ref) => {
      const el = ref.current;
      if (!el) return;
      const items = el.querySelectorAll("[data-animate]");
      gsap.set(items, { opacity: 0, y: 30 });
      gsap.to(items, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: el,
          start: "top 80%",
          toggleActions: "play none none none",
        },
      });
    });
  }, []);

  return (
    <>
      <PageHero
        breadcrumb={[{ label: "首页", href: "/" }, { label: "关于我们" }]}
        title="关于英迪尔"
        subtitle="万店级商厨设备智造商 · 专注连锁餐饮14年"
      />

      {/* Company Story */}
      <section className="bg-white section-padding" ref={storyRef}>
        <div className="content-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div data-animate className="aspect-[4/3] rounded overflow-hidden">
              <img
                src="/assets/factory.jpg"
                alt="英迪尔工厂"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <span
                data-animate
                className="text-[13px] text-muted-text tracking-[0.15em] font-light uppercase"
              >
                OUR STORY
              </span>
              <h2
                data-animate
                className="font-serif text-2xl md:text-[32px] font-medium text-charcoal mt-4"
              >
                从番禺走向世界
              </h2>
              <div className="mt-6 space-y-4 text-base text-charcoal font-light leading-relaxed">
                <p data-animate>
                  英迪尔电器有限公司成立于2012年11月，总部位于广州市番禺区——中国制造业的核心地带之一。从一间小型工厂起步，英迪尔凭借对品质的执着追求和对连锁餐饮需求的深刻理解，迅速成长为国内领先的商厨设备制造商。
                </p>
                <p data-animate>
                  14年来，我们始终专注于连锁餐饮厨房设备的研发与制造，服务范围覆盖全国34个省市自治区，并出口至全球30多个国家和地区。从海底捞到汉堡王，从蜜雪冰城到正新鸡排——超过1000家连锁餐饮品牌选择了英迪尔。
                </p>
                <p
                  data-animate
                  className="border-l-[3px] border-crimson pl-5 text-crimson font-normal mt-6"
                >
                  我们的使命很简单：用精良的设备，助力每一家连锁餐饮企业实现标准化、高效化运营。
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Band */}
      <section className="bg-charcoal py-16 md:py-20">
        <div className="content-container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-10 text-center">
            <div ref={yearCount.ref}>
              <span className="text-5xl md:text-6xl font-bold text-crimson">
                {yearCount.displayValue}
              </span>
              <p className="text-base text-white mt-3">成立年份</p>
              <p className="text-sm text-white/40 mt-1">扎根番禺，专注商厨</p>
            </div>
            <div ref={staffCount.ref}>
              <span className="text-5xl md:text-6xl font-bold text-crimson">
                {staffCount.displayValue}
              </span>
              <p className="text-base text-white mt-3">专业人员</p>
              <p className="text-sm text-white/40 mt-1">研发团队近30人</p>
            </div>
            <div ref={clientCount.ref}>
              <span className="text-5xl md:text-6xl font-bold text-crimson">
                {clientCount.displayValue}
              </span>
              <p className="text-base text-white mt-3">连锁客户</p>
              <p className="text-sm text-white/40 mt-1">遍布全球30+国家</p>
            </div>
            <div ref={areaCount.ref}>
              <span className="text-5xl md:text-6xl font-bold text-crimson">
                {areaCount.displayValue}㎡
              </span>
              <p className="text-base text-white mt-3">生产基地</p>
              <p className="text-sm text-white/40 mt-1">先进制造设备</p>
            </div>
          </div>
        </div>
      </section>

      {/* Advantages */}
      <section className="bg-warm-white section-padding" ref={advRef}>
        <div className="content-container">
          <div className="text-center mb-12 md:mb-16">
            <span className="text-[13px] text-muted-text tracking-[0.15em] font-light uppercase">
              WHY INIDEA
            </span>
            <h2 className="text-3xl md:text-[44px] font-light text-charcoal tracking-wide mt-3">
              英迪尔的核心优势
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {advantages.map((adv) => {
              const Icon = advantageIcons[adv.icon] || Factory;
              return (
                <div
                  key={adv.title}
                  data-animate
                  className="bg-white p-8 md:p-10 rounded group hover:-translate-y-1 hover:shadow-lg transition-all duration-350"
                >
                  <Icon size={48} strokeWidth={1.5} className="text-charcoal" />
                  <h3 className="text-xl font-medium text-charcoal mt-6">
                    {adv.title}
                  </h3>
                  <p className="text-[15px] text-muted-text font-light leading-relaxed mt-3">
                    {adv.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="bg-white section-padding" ref={certRef}>
        <div className="content-container">
          <div className="text-center mb-12 md:mb-16">
            <span className="text-[13px] text-muted-text tracking-[0.15em] font-light uppercase">
              CERTIFICATIONS
            </span>
            <h2 className="text-3xl md:text-[44px] font-light text-charcoal tracking-wide mt-3">
              荣誉资质
            </h2>
            <p className="text-base text-muted-text font-light mt-3">
              具有多项专利证书，并有ISO、ETL、CE等多项认证
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 md:gap-6">
            {certifications.map((cert) => (
              <div
                key={cert.name}
                data-animate
                className="bg-white border border-[#F0EDE8] rounded p-6 md:p-8 text-center hover:shadow-md transition-shadow duration-300"
              >
                <Award size={32} className="text-crimson mx-auto" />
                <p className="text-sm font-medium text-charcoal mt-4">
                  {cert.name}
                </p>
                <p className="text-xs text-muted-text font-light mt-1">
                  {cert.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTABanner />
    </>
  );
}
