import { useState, useEffect, useRef } from "react";
import { Link, useParams } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  Check,
  ArrowRight,
  Phone,
  Shield,
  Droplets,
  Thermometer,
  Flame,
} from "lucide-react";
import PageHero from "../components/PageHero";
import { productDetail, allProducts, contactInfo } from "../data/siteData";

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<string, React.ElementType> = {
  Shield,
  Droplets,
  Thermometer,
  Flame,
};

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [activeTab, setActiveTab] = useState(0);
  const [activeImage, setActiveImage] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  const tabs = ["产品详情", "技术参数", "产品特点"];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    gsap.from(el.querySelectorAll("[data-pd-animate]"), {
      opacity: 0,
      y: 25,
      duration: 0.8,
      stagger: 0.1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        toggleActions: "play none none none",
      },
    });
  }, []);

  const relatedProducts = allProducts
    .filter((p) => p.id !== productDetail.id)
    .slice(0, 4);

  return (
    <>
      <PageHero
        breadcrumb={[
          { label: "首页", href: "/" },
          { label: "产品中心", href: "/products" },
          { label: productDetail.category, href: "/products" },
          { label: productDetail.name },
        ]}
        title={productDetail.name}
      />

      {/* Product Hero Gallery */}
      <section className="bg-white py-10 md:py-16" ref={sectionRef}>
        <div className="content-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16">
            {/* Image Gallery */}
            <div data-pd-animate>
              <div className="aspect-[4/3] bg-light-grey rounded overflow-hidden">
                <img
                  src={productDetail.images[activeImage]}
                  alt={productDetail.name}
                  className="w-full h-full object-contain p-4 transition-opacity duration-300"
                />
              </div>
              <div className="flex gap-3 mt-4">
                {productDetail.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`w-20 h-20 rounded overflow-hidden border-2 transition-colors ${
                      activeImage === i
                        ? "border-crimson"
                        : "border-transparent hover:border-warm-stone"
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${productDetail.name} ${i + 1}`}
                      className="w-full h-full object-contain p-1 bg-light-grey"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div data-pd-animate>
              <span className="text-[13px] text-crimson tracking-wider">
                {productDetail.category}
              </span>
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mt-3 leading-tight">
                {productDetail.name}
              </h2>
              <p className="text-base text-muted-text font-light mt-3">
                {productDetail.subtitle}
              </p>

              <ul className="mt-6 space-y-3">
                {productDetail.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check
                      size={18}
                      className="text-crimson shrink-0 mt-0.5"
                    />
                    <span className="text-[15px] text-charcoal">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <Link
                  to="/contact"
                  className="px-10 py-4 bg-crimson text-white font-medium text-center hover:brightness-110 hover:-translate-y-0.5 transition-all duration-300"
                >
                  立即咨询
                </Link>
              </div>

              <div className="mt-6 text-sm text-muted-text">
                <span>或致电咨询：</span>
                <a
                  href={`tel:${contactInfo.hotline}`}
                  className="text-crimson font-medium ml-1 inline-flex items-center gap-1"
                >
                  <Phone size={14} />
                  {contactInfo.hotline}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tabs Section */}
      <section className="bg-warm-white py-12 md:py-16">
        <div className="content-container">
          {/* Tab Navigation */}
          <div className="flex justify-center border-b border-warm-stone">
            {tabs.map((tab, i) => (
              <button
                key={tab}
                onClick={() => setActiveTab(i)}
                className={`px-6 md:px-8 py-4 text-base transition-colors border-b-2 -mb-[1px] ${
                  activeTab === i
                    ? "text-charcoal border-crimson"
                    : "text-muted-text border-transparent hover:text-charcoal"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="pt-10 md:pt-12">
            {activeTab === 0 && (
              <div className="max-w-3xl">
                <h3 className="text-2xl font-medium text-charcoal mb-4">
                  产品概述
                </h3>
                <p className="text-base text-charcoal font-light leading-relaxed">
                  {productDetail.name}专为连锁餐饮、快餐店、炸鸡店等商业厨房设计。采用食品级304不锈钢机身，配备一键自动滤油系统，可有效延长食用油使用寿命。6段精准温控系统满足不同食材的炸制需求，控温精度达到±1°C，确保每次出品品质如一。
                </p>
                <h3 className="text-2xl font-medium text-charcoal mt-10 mb-4">
                  适用范围
                </h3>
                <ul className="space-y-2 text-base text-charcoal font-light">
                  <li>· 连锁炸鸡店、汉堡店</li>
                  <li>· 中西式快餐门店</li>
                  <li>· 小吃店、美食广场</li>
                  <li>· 酒店、学校、企业食堂</li>
                </ul>
              </div>
            )}

            {activeTab === 1 && (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[500px]">
                  <tbody>
                    {productDetail.specs.map((spec, i) => (
                      <tr
                        key={spec.param}
                        className={`border-b border-[#F0EDE8] ${
                          i % 2 === 1 ? "bg-white/50" : ""
                        }`}
                      >
                        <td className="py-4 px-6 text-[15px] font-medium text-charcoal w-[35%]">
                          {spec.param}
                        </td>
                        <td className="py-4 px-6 text-[15px] text-muted-text">
                          {spec.value}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 2 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {productDetail.featureCards.map((card) => {
                  const Icon = iconMap[card.icon] || Shield;
                  return (
                    <div
                      key={card.title}
                      className="bg-white p-8 rounded"
                    >
                      <Icon size={32} className="text-crimson" />
                      <h4 className="text-lg font-medium text-charcoal mt-4">
                        {card.title}
                      </h4>
                      <p className="text-[15px] text-muted-text font-light leading-relaxed mt-2">
                        {card.desc}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Related Products */}
      <section className="bg-white py-12 md:py-16">
        <div className="content-container">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-2xl font-light text-charcoal">
              同系列产品
            </h3>
            <Link
              to="/products"
              className="text-sm text-crimson flex items-center gap-1 hover:underline"
            >
              查看全部 <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {relatedProducts.map((product) => (
              <Link
                key={product.id}
                to={`/products/${product.id}`}
                className="group"
              >
                <div className="aspect-[3/2] bg-light-grey rounded-t overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-contain p-2 transition-transform duration-300 group-hover:scale-[1.03]"
                    loading="lazy"
                  />
                </div>
                <div className="p-4 border border-t-0 border-[#F0EDE8] rounded-b">
                  <h4 className="text-[15px] font-medium text-charcoal group-hover:text-crimson transition-colors">
                    {product.name}
                  </h4>
                  <span className="text-[13px] text-crimson mt-2 flex items-center gap-1">
                    了解详情 <ArrowRight size={13} />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Inquiry CTA */}
      <section className="bg-charcoal">
        <div className="content-container py-16 md:py-20 text-center max-w-[800px] flex flex-col items-center">
          <span className="text-[13px] text-white/30 tracking-[0.15em] uppercase">
            GET A QUOTE
          </span>
          <h3 className="font-serif text-3xl md:text-4xl font-medium text-white mt-4">
            对这款产品感兴趣？
          </h3>
          <p className="text-base text-white/50 font-light leading-relaxed mt-4 max-w-[560px]">
            我们的专业顾问将根据您的门店规模和需求，为您提供定制化的设备配置方案和报价。
          </p>
          <Link
            to="/contact"
            className="inline-block mt-8 px-12 py-4 bg-crimson text-white font-medium hover:brightness-110 hover:-translate-y-0.5 transition-all duration-300"
          >
            立即获取报价
          </Link>
          <p className="text-white/30 text-sm mt-5">
            或致电 {contactInfo.hotline}
          </p>
        </div>
      </section>
    </>
  );
}
