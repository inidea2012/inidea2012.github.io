# Tech Spec — INIDEA Website

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^19.1.0 | UI framework |
| react-dom | ^19.1.0 | DOM renderer |
| react-router-dom | ^7.6.0 | Client-side routing (7 pages) |
| gsap | ^3.12.2 | Animation engine, ScrollTrigger, SplitText |
| lenis | ^1.2.3 | Smooth scroll with inertia |
| lucide-react | ^0.510.0 | Icon system |
| tailwindcss | ^4.1.6 | Utility-first CSS |
| @tailwindcss/vite | ^4.1.6 | Tailwind Vite integration |
| typescript | ^5.8.0 | Type safety |
| vite | ^6.3.0 | Build tool |
| @vitejs/plugin-react | ^4.4.0 | React Vite plugin |

No shadcn/ui components — the design is fully custom editorial with no standard UI primitives.

---

## Component Inventory

### Layout (shared across all pages)

| Component | Source | Notes |
|-----------|--------|-------|
| Header | Custom | Two variants (Hero/transparent + Solid). Scroll-aware state via IntersectionObserver on hero sentinel. Mobile hamburger overlay. |
| Footer | Custom | 4-column grid on Charcoal bg. Static — no animations beyond basic entrance. |
| StickyServiceSidebar | Custom | Fixed right-side panel (desktop), FAB on mobile. |
| PageLoader | Custom | White overlay + crimson progress line for route transitions. |

### Sections (page-specific, used once each)

**Homepage:**
| Component | Notes |
|-----------|-------|
| HeroSection | Full-viewport, 12x12 CSS Grid, SplitText character animation |
| ProductCategories | 4x2 grid, hover overlay with slide-up reveal |
| FeaturedProducts | 3x2 grid on cream bg, product cards |
| BrandTrust | Two-column: stat block left, logo grid right. Count-up number. |
| OneStopServices | 4-column icon cards |
| AboutPreview | Two-column: stats left, narrative right |
| NewsPreview | 3-column article cards |
| CTABanner | Dark centered CTA, reused on multiple pages |

**About:**
| Component | Notes |
|-----------|-------|
| AboutHero | Compact breadcrumb + title |
| CompanyStory | Two-column: image left, text right |
| CompanyStats | 4-column stat band with count-up |
| OurAdvantages | 4-column advantage cards |
| Certifications | 5-column badge grid |

**Products:**
| Component | Notes |
|-----------|-------|
| ProductsHero | Compact breadcrumb + title |
| ProductFilterSidebar | Sticky sidebar (desktop), horizontal tabs (tablet), dropdown (mobile) |
| ProductGrid | 3-column grid with pagination |
| ProductCard | Image + category tag + name + features + link |

**ProductDetail:**
| Component | Notes |
|-----------|-------|
| ProductHeroGallery | Two-column: image gallery left, info right. Thumbnail strip. |
| ProductTabs | Tabbed content (Details / Specs / Features). Manual tab switching with GSAP fade. |
| SpecTable | Styled HTML table with alternating rows |
| FeatureHighlights | 2-column feature cards |
| RelatedProducts | 4-column compact product cards |
| InquiryCTA | Compact dark CTA section |

**News:**
| Component | Notes |
|-----------|-------|
| NewsHero | Compact breadcrumb + title + category tabs |
| FeaturedArticle | Full-width two-column card |
| ArticleGrid | 2-column article cards |

**NewsDetail:**
| Component | Notes |
|-----------|-------|
| ArticleHeader | Narrow column (800px), breadcrumb + title + meta + hero image |
| ArticleBody | Rich text content (800px reading column) |
| ArticleFooter | Tags + share links |
| ArticleNavigation | Prev/next cards |
| RelatedArticles | 3-column article cards |
| MiniCTA | Compact dark CTA |

**Contact:**
| Component | Notes |
|-----------|-------|
| ContactHero | Compact breadcrumb + title |
| ContactForm | 5-field form (name, email, phone, company, message) |
| ContactInfoPanel | 5 contact items with icons + QR code placeholder |
| MapSection | Static map image with overlay gradient |
| ServiceChannels | 3-column service cards |

### Reusable Components

| Component | Used By | Notes |
|-----------|---------|-------|
| PageHero | About, Products, News, Contact | Compact breadcrumb + title. Accepts label, title, subtitle, optional tabs. |
| CTABanner | Homepage, About, Products, News | Full-width dark CTA. Accepts heading lines, description, button config. |
| SectionHeading | Multiple sections | Label (uppercase) + heading + optional subtitle. Left-aligned or centered. |
| NewsCard | NewsPreview, News, NewsDetail, RelatedArticles | Image + category + date + title + link. Consistent across all contexts. |
| ProductCard | FeaturedProducts, ProductGrid, RelatedProducts | Image + category + name + features + link. Compact variant for RelatedProducts. |
| CategoryCard | ProductCategories | Image + hover overlay with slide-up reveal. |
| ServiceCard | OneStopServices, ServiceChannels | Icon circle + title + description. |
| AdvantageCard | OurAdvantages | Icon + title + description on white bg with hover lift. |
| Pagination | Products, News | Page number buttons with prev/next arrows. |
| StatBlock | BrandTrust, CompanyStats, AboutPreview | Large number + label + optional sub-label. |
| Breadcrumb | All inner pages | Home link + segments. |

### Hooks

| Hook | Purpose |
|------|---------|
| useScrollAnimation | Registers GSAP ScrollTrigger entrance animations (fade + translateY) on a ref. Accepts delay, stagger options. |
| useCountUp | Animates a number from 0 to target on scroll trigger. Returns ref + current value. |
| useHeaderState | Returns "hero" | "scrolled" | "solid" based on scroll position and current page. |
| useLenis | Initializes Lenis, syncs with GSAP ScrollTrigger, exposes scrollTo. |

---

## Animation Implementation

| Animation | Library | Approach | Complexity |
|-----------|---------|----------|------------|
| Smooth scrolling | Lenis | Global init, synced with ScrollTrigger via `lenis.on('scroll', ScrollTrigger.update)` | Low |
| Default scroll entrance | GSAP ScrollTrigger | Batch registration: query all `[data-animate]` elements, apply `fromTo({opacity:0,y:40}, {opacity:1,y:0})` with stagger | Low |
| Hero text entrance (SplitText) | GSAP + SplitText | Split hero headline into chars, stagger `translateY(120%)→0` + opacity. Chain with subtitle/CTA delays. | **High** 🔒 |
| Nav underline slide | CSS transform | Single pseudo-element, `translateX` animated via CSS transition based on active link index | Low |
| Header scroll transition | CSS + IntersectionObserver | Observer on hero sentinel toggles CSS class. Background/color transition via CSS `transition`. | Low |
| Card hover effects | CSS transitions | `transform: scale(1.05)` on image, `translateY(-4px)` + `box-shadow` on card. Pure CSS. | Low |
| Count-up stats | GSAP ScrollTrigger + gsap.to | `gsap.to(proxyObj, {value: target, onUpdate})` triggered by ScrollTrigger. Custom hook. | Medium |
| Tab content switch | GSAP | Fade out current (opacity 0.15s), then fade in new (opacity + translateY 0.3s). Sequential timeline. | Medium |
| Page loader | GSAP Timeline | Progress line `scaleX(0→1)` 0.8s ease-in-out, then overlay `opacity→0` 0.4s. Timeline plays on route change. | Medium |
| Gallery crossfade | CSS transition | Main image opacity transition 0.3s on thumbnail click. React state drives `src` swap. | Low |
| Sidebar/service hover | CSS transitions | Background/color/icon color swaps. Pure CSS. | Low |
| Mobile menu overlay | GSAP | Full-screen overlay slides in from right, links stagger in. Reverse on close. | Medium |

---

## State & Logic

No global state library needed. All state is local or URL-driven:

- **Active nav tab**: Derived from `useLocation()` pathname
- **Product filter**: Local state in `Products` page, passed to `ProductFilterSidebar` + `ProductGrid`
- **News category filter**: Local state in `News` page
- **Product detail active tab**: Local state in `ProductDetail` page
- **Gallery active image**: Local state in `ProductHeroGallery`
- **Form submission**: Local state (loading → success) in `ContactForm`
- **Mobile menu open**: Local state in `Header`
- **Page loader active**: Managed by a context at router level, triggered on route changes

---

## Other Key Decisions

**Routing**: React Router v7 with `BrowserRouter`. 7 routes defined in `App.tsx`.

**No image optimization library**: Product/article images are referenced by description for generation by the development agent. No Next.js Image component — standard `<img>` with lazy loading (`loading="lazy"`).

**No i18n**: Single-language Chinese site. No internationalization needed.

**Static site**: No CMS, no API calls. All content is hardcoded in components. This is a presentation/portfolio site.

**Font loading**: Google Fonts loaded via `<link>` in `index.html` for Noto Sans SC (300,400,500,700) and Noto Serif SC (500,700). Font-display: swap.
